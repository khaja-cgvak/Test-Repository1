<div class="col-sm-12"><br><br><br>
	<div class="alert alert-danger text-center"><h4>You dont't have permission to access this page. Please contact our Administrator.</h4></div>
</div>
<div class="clearfix"></div>