<section class="vbox">
	<section class="scrollable padder">
		<section class="panel panel-default">
			<header class="panel-heading"><b><?php echo $title; ?></b></header>
			<div class="">
				<table class="table table-striped m-b-none table-bordered dt-responsive nowrap" id="projectlist_exports" width="100%">
					<thead>
						<tr>
							<th width="19%">Project Name</th>
							<th width="15%">Start Date</th>
							<th width="15%">End Date</th>
							<th width="27%">Project<br>Description</th>
							<th width="19%">Customer<br>Name</th>							
							<th width="5%">Action</th>
						</tr>
					</thead>					
				</table>
			</div>
		</section>
	</section>
</section>